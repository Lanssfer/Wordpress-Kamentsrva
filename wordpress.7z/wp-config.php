<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать файл в "wp-config.php"
 * и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки базы данных
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры базы данных: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'mysite2' );

/** Имя пользователя базы данных */
define( 'DB_USER', 'admin' );

/** Пароль к базе данных */
define( 'DB_PASSWORD', '2121o' );

/** Имя сервера базы данных */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу. Можно сгенерировать их с помощью
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}.
 *
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными.
 * Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'oMT*H>Xb}nqzq)?^t]:Rb)!a(CkUFw~gZz*5g5HX?5;CFbJix!+zZotl[Sn (YMo' );
define( 'SECURE_AUTH_KEY',  '*AOg3]!L:/-!%}{yv(TAePr1L0[1QiX&m_CUOQWTDeepi3?I$CQJ( po0Veo8r2r' );
define( 'LOGGED_IN_KEY',    '`z>QAXVqL~Defx: sCX8@[cw]R X&vEC2@kib-%~4>Up_s1r~s&7Q*9pXGEX#{0;' );
define( 'NONCE_KEY',        'v}? kY+maCfS#RLQl*PKSm6)c6;.xBERtij;jaaVXaZ*[6|NDxT+Fr+$,t!#H;qi' );
define( 'AUTH_SALT',        'oB(6*xnnx9WA7d4YQW+zVEp`tZ8#R|sESC;sP0v^Q#L UYs-DX4raC!czfbYRa]J' );
define( 'SECURE_AUTH_SALT', 'kDErqL]Ao;|cmQa2iw*ck{$4 En2AEp@kZ|hmhatx^#r_JX-Z*wKpCm<QWkYkj|V' );
define( 'LOGGED_IN_SALT',   ']V@frMHvyg5{FebTM`6Gu#f*kn?zdJ8#S|Sc_JDiHLKJc38h!1%POsYKE2m)w(7_' );
define( 'NONCE_SALT',       'h#LJhjL.z!Z$/iuGRN7Jg-s3nP)WV!ixIalSl7Vqwm>Oj8W$7eStagEAs?}kcbN6' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Произвольные значения добавляйте между этой строкой и надписью "дальше не редактируем". */



/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
